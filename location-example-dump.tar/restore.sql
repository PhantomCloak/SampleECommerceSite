--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE locations;
--
-- Name: locations; Type: DATABASE; Schema: -; Owner: service
--

CREATE DATABASE locations WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE locations OWNER TO service;

\connect locations

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: locations; Type: DATABASE PROPERTIES; Schema: -; Owner: service
--

ALTER DATABASE locations SET search_path TO '$user', 'public', 'tiger';


\connect locations

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: service
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO service;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: service
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO service;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: service
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO service;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: service
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    country_tag character varying(4)
);


ALTER TABLE public.countries OWNER TO service;

--
-- Name: districts; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.districts (
    district_id integer NOT NULL,
    province_id integer,
    district_name character varying(128)
);


ALTER TABLE public.districts OWNER TO service;

--
-- Name: neighborhoods; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.neighborhoods (
    neighborhood_id integer NOT NULL,
    district_id integer,
    neighborhood_name character varying(128),
    postal_code character varying(16),
    latitude numeric(10,8),
    longitude numeric(11,8)
);


ALTER TABLE public.neighborhoods OWNER TO service;

--
-- Name: neighborhoods_neighborhood_id_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.neighborhoods_neighborhood_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.neighborhoods_neighborhood_id_seq OWNER TO service;

--
-- Name: neighborhoods_neighborhood_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: service
--

ALTER SEQUENCE public.neighborhoods_neighborhood_id_seq OWNED BY public.neighborhoods.neighborhood_id;


--
-- Name: province; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.province (
    province_id integer NOT NULL,
    country_id integer,
    province_name character varying(128)
);


ALTER TABLE public.province OWNER TO service;

--
-- Name: province_province_id_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.province_province_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.province_province_id_seq OWNER TO service;

--
-- Name: province_province_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: service
--

ALTER SEQUENCE public.province_province_id_seq OWNED BY public.province.province_id;


--
-- Name: neighborhoods neighborhood_id; Type: DEFAULT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.neighborhoods ALTER COLUMN neighborhood_id SET DEFAULT nextval('public.neighborhoods_neighborhood_id_seq'::regclass);


--
-- Name: province province_id; Type: DEFAULT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.province ALTER COLUMN province_id SET DEFAULT nextval('public.province_province_id_seq'::regclass);


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.countries (id, country_tag) FROM stdin;
\.
COPY public.countries (id, country_tag) FROM '$$PATH$$/4448.dat';

--
-- Data for Name: districts; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.districts (district_id, province_id, district_name) FROM stdin;
\.
COPY public.districts (district_id, province_id, district_name) FROM '$$PATH$$/4450.dat';

--
-- Data for Name: neighborhoods; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.neighborhoods (neighborhood_id, district_id, neighborhood_name, postal_code, latitude, longitude) FROM stdin;
\.
COPY public.neighborhoods (neighborhood_id, district_id, neighborhood_name, postal_code, latitude, longitude) FROM '$$PATH$$/4451.dat';

--
-- Data for Name: province; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.province (province_id, country_id, province_name) FROM stdin;
\.
COPY public.province (province_id, country_id, province_name) FROM '$$PATH$$/4449.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/4101.dat';

--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: service
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.
COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM '$$PATH$$/4104.dat';

--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: service
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.
COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM '$$PATH$$/4105.dat';

--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: service
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.
COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM '$$PATH$$/4106.dat';

--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: service
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.
COPY tiger.pagc_rules (id, rule, is_custom) FROM '$$PATH$$/4107.dat';

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: service
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.
COPY topology.topology (id, name, srid, "precision", hasz) FROM '$$PATH$$/4102.dat';

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: service
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.
COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM '$$PATH$$/4103.dat';

--
-- Name: neighborhoods_neighborhood_id_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.neighborhoods_neighborhood_id_seq', 1, false);


--
-- Name: province_province_id_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.province_province_id_seq', 1, false);


--
-- Name: countries countries_pk; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pk PRIMARY KEY (id);


--
-- Name: districts districts_pk; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_pk PRIMARY KEY (district_id);


--
-- Name: neighborhoods neighborhoods_pk; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.neighborhoods
    ADD CONSTRAINT neighborhoods_pk PRIMARY KEY (neighborhood_id);


--
-- Name: province province_pk; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT province_pk PRIMARY KEY (province_id);


--
-- Name: countries_country_tag_uindex; Type: INDEX; Schema: public; Owner: service
--

CREATE UNIQUE INDEX countries_country_tag_uindex ON public.countries USING btree (country_tag);


--
-- Name: districts_district_name_index; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX districts_district_name_index ON public.districts USING btree (district_name);


--
-- Name: districts_province_id_index; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX districts_province_id_index ON public.districts USING btree (province_id);


--
-- Name: neighborhoods_district_id_index; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX neighborhoods_district_id_index ON public.neighborhoods USING btree (district_id);


--
-- Name: neighborhoods_longitude_latitude_index; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX neighborhoods_longitude_latitude_index ON public.neighborhoods USING btree (longitude, latitude);


--
-- Name: neighborhoods_postal_code_index; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX neighborhoods_postal_code_index ON public.neighborhoods USING btree (postal_code);


--
-- Name: province_country_id_index; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX province_country_id_index ON public.province USING btree (country_id);


--
-- Name: districts districts_province_province_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_province_province_id_fk FOREIGN KEY (province_id) REFERENCES public.province(province_id);


--
-- Name: neighborhoods neighborhoods_districts_district_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.neighborhoods
    ADD CONSTRAINT neighborhoods_districts_district_id_fk FOREIGN KEY (district_id) REFERENCES public.districts(district_id);


--
-- Name: province province_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT province_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- PostgreSQL database dump complete
--

