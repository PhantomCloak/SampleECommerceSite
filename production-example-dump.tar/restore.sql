--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE efurni;
--
-- Name: efurni; Type: DATABASE; Schema: -; Owner: service
--

CREATE DATABASE efurni WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE efurni OWNER TO service;

\connect efurni

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: account_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.account_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_seq OWNER TO service;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.account (
    account_id integer DEFAULT nextval('public.account_seq'::regclass) NOT NULL,
    email character varying(64) NOT NULL,
    password character varying(64) NOT NULL,
    deleted boolean NOT NULL,
    deleted_at date
);


ALTER TABLE public.account OWNER TO service;

--
-- Name: basket_item; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.basket_item (
    basket_item_id integer NOT NULL,
    basket_id integer NOT NULL,
    product_id integer NOT NULL,
    amount integer NOT NULL
);


ALTER TABLE public.basket_item OWNER TO service;

--
-- Name: brand_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.brand_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.brand_seq OWNER TO service;

--
-- Name: brand; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.brand (
    brand_id integer DEFAULT nextval('public.brand_seq'::regclass) NOT NULL,
    brand_name character varying(64) NOT NULL
);


ALTER TABLE public.brand OWNER TO service;

--
-- Name: category_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.category_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_seq OWNER TO service;

--
-- Name: category; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.category (
    category_id integer DEFAULT nextval('public.category_seq'::regclass) NOT NULL,
    category_name character varying(32) NOT NULL
);


ALTER TABLE public.category OWNER TO service;

--
-- Name: customer_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.customer_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_seq OWNER TO service;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.customer (
    customer_id integer DEFAULT nextval('public.customer_seq'::regclass) NOT NULL,
    account_id integer NOT NULL,
    first_name character varying(32) NOT NULL,
    last_name character varying(32) NOT NULL,
    profile_picture_url text NOT NULL,
    phone_number character varying(48)
);


ALTER TABLE public.customer OWNER TO service;

--
-- Name: customer_basket_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.customer_basket_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_basket_seq OWNER TO service;

--
-- Name: customer_basket; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.customer_basket (
    basket_id integer DEFAULT nextval('public.customer_basket_seq'::regclass) NOT NULL,
    customer_id integer NOT NULL
);


ALTER TABLE public.customer_basket OWNER TO service;

--
-- Name: customer_order_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.customer_order_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_order_seq OWNER TO service;

--
-- Name: customer_order; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.customer_order (
    order_id integer DEFAULT nextval('public.customer_order_seq'::regclass) NOT NULL,
    customer_id integer,
    receiver_first character varying(32) NOT NULL,
    receiver_last character varying(32) NOT NULL,
    phone_number character varying(32) NOT NULL,
    optional_mail character varying(64),
    postal_service_id integer,
    coupon_discount integer NOT NULL,
    order_status character varying(32) NOT NULL,
    order_date date NOT NULL,
    required_date date NOT NULL,
    shipped_date date NOT NULL,
    additional_note text,
    total_price double precision NOT NULL,
    cargo_price double precision NOT NULL
);


ALTER TABLE public.customer_order OWNER TO service;

--
-- Name: customer_order_address; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.customer_order_address (
    id integer NOT NULL,
    order_id integer NOT NULL,
    country_tag character varying(4) NOT NULL,
    province character varying(64) NOT NULL,
    district character varying(64) NOT NULL,
    neighborhood character varying(64) NOT NULL,
    destination_zip_code character varying(12) NOT NULL,
    address_text_primary text NOT NULL,
    address_text_secondary text
);


ALTER TABLE public.customer_order_address OWNER TO service;

--
-- Name: customer_order_address_id_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.customer_order_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_order_address_id_seq OWNER TO service;

--
-- Name: customer_order_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: service
--

ALTER SEQUENCE public.customer_order_address_id_seq OWNED BY public.customer_order_address.id;


--
-- Name: customer_order_item_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.customer_order_item_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_order_item_seq OWNER TO service;

--
-- Name: customer_order_item; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.customer_order_item (
    customer_order_item_id integer DEFAULT nextval('public.customer_order_item_seq'::regclass) NOT NULL,
    order_id integer,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    list_price double precision NOT NULL,
    product_discount integer NOT NULL,
    store_id integer
);


ALTER TABLE public.customer_order_item OWNER TO service;

--
-- Name: customer_review; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.customer_review (
    review_id integer NOT NULL,
    customer_id integer NOT NULL,
    customer_comment text NOT NULL,
    customer_rating double precision NOT NULL,
    product_id integer NOT NULL,
    reply_review_id integer
);


ALTER TABLE public.customer_review OWNER TO service;

--
-- Name: customer_review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.customer_review_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_review_review_id_seq OWNER TO service;

--
-- Name: customer_review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: service
--

ALTER SEQUENCE public.customer_review_review_id_seq OWNED BY public.customer_review.review_id;


--
-- Name: customer_review_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.customer_review_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_review_seq OWNER TO service;

--
-- Name: postal_service; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.postal_service (
    service_id integer NOT NULL,
    postalservicename character varying(32) NOT NULL,
    price double precision NOT NULL,
    avg_delivery_day integer
);


ALTER TABLE public.postal_service OWNER TO service;

--
-- Name: product_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.product_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_seq OWNER TO service;

--
-- Name: product; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.product (
    product_id integer DEFAULT nextval('public.product_seq'::regclass) NOT NULL,
    product_name character varying(128) NOT NULL,
    brand_id integer NOT NULL,
    category_id integer NOT NULL,
    sub_type character varying(16) NOT NULL,
    product_color character varying(16) NOT NULL,
    product_image text NOT NULL,
    product_width double precision NOT NULL,
    product_height double precision NOT NULL,
    product_weight double precision NOT NULL,
    box_pieces integer NOT NULL,
    model_year integer NOT NULL,
    list_price double precision NOT NULL,
    discount integer NOT NULL,
    description text NOT NULL,
    listed smallint NOT NULL
);


ALTER TABLE public.product OWNER TO service;

--
-- Name: product_sales_statistic; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.product_sales_statistic (
    product_id integer NOT NULL,
    number_sold integer NOT NULL,
    product_rating double precision NOT NULL,
    number_viewed integer NOT NULL,
    date_added date NOT NULL
);


ALTER TABLE public.product_sales_statistic OWNER TO service;

--
-- Name: stock_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.stock_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_seq OWNER TO service;

--
-- Name: stock; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.stock (
    stock_id integer DEFAULT nextval('public.stock_seq'::regclass) NOT NULL,
    store_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.stock OWNER TO service;

--
-- Name: store_seq; Type: SEQUENCE; Schema: public; Owner: service
--

CREATE SEQUENCE public.store_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_seq OWNER TO service;

--
-- Name: store; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.store (
    store_id integer DEFAULT nextval('public.store_seq'::regclass) NOT NULL,
    store_name character varying(64) NOT NULL,
    phone_number character varying(48) NOT NULL,
    email character varying(64) NOT NULL
);


ALTER TABLE public.store OWNER TO service;

--
-- Name: store_address; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.store_address (
    store_id integer NOT NULL,
    country_tag character varying(4) NOT NULL,
    province character varying(64) NOT NULL,
    district character varying(64) NOT NULL,
    neighborhood character varying(64) NOT NULL,
    zip_code character varying(32) NOT NULL,
    address_text_primary text NOT NULL,
    address_text_secondary text
);


ALTER TABLE public.store_address OWNER TO service;

--
-- Name: store_sales_statistic; Type: TABLE; Schema: public; Owner: service
--

CREATE TABLE public.store_sales_statistic (
    store_id integer NOT NULL,
    item_sold integer NOT NULL
);


ALTER TABLE public.store_sales_statistic OWNER TO service;

--
-- Name: customer_order_address id; Type: DEFAULT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order_address ALTER COLUMN id SET DEFAULT nextval('public.customer_order_address_id_seq'::regclass);


--
-- Name: customer_review review_id; Type: DEFAULT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_review ALTER COLUMN review_id SET DEFAULT nextval('public.customer_review_review_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.account (account_id, email, password, deleted, deleted_at) FROM stdin;
\.
COPY public.account (account_id, email, password, deleted, deleted_at) FROM '$$PATH$$/3162.dat';

--
-- Data for Name: basket_item; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.basket_item (basket_item_id, basket_id, product_id, amount) FROM stdin;
\.
COPY public.basket_item (basket_item_id, basket_id, product_id, amount) FROM '$$PATH$$/3181.dat';

--
-- Data for Name: brand; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.brand (brand_id, brand_name) FROM stdin;
\.
COPY public.brand (brand_id, brand_name) FROM '$$PATH$$/3155.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.category (category_id, category_name) FROM stdin;
\.
COPY public.category (category_id, category_name) FROM '$$PATH$$/3157.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.customer (customer_id, account_id, first_name, last_name, profile_picture_url, phone_number) FROM stdin;
\.
COPY public.customer (customer_id, account_id, first_name, last_name, profile_picture_url, phone_number) FROM '$$PATH$$/3163.dat';

--
-- Data for Name: customer_basket; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.customer_basket (basket_id, customer_id) FROM stdin;
\.
COPY public.customer_basket (basket_id, customer_id) FROM '$$PATH$$/3180.dat';

--
-- Data for Name: customer_order; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.customer_order (order_id, customer_id, receiver_first, receiver_last, phone_number, optional_mail, postal_service_id, coupon_discount, order_status, order_date, required_date, shipped_date, additional_note, total_price, cargo_price) FROM stdin;
\.
COPY public.customer_order (order_id, customer_id, receiver_first, receiver_last, phone_number, optional_mail, postal_service_id, coupon_discount, order_status, order_date, required_date, shipped_date, additional_note, total_price, cargo_price) FROM '$$PATH$$/3173.dat';

--
-- Data for Name: customer_order_address; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.customer_order_address (id, order_id, country_tag, province, district, neighborhood, destination_zip_code, address_text_primary, address_text_secondary) FROM stdin;
\.
COPY public.customer_order_address (id, order_id, country_tag, province, district, neighborhood, destination_zip_code, address_text_primary, address_text_secondary) FROM '$$PATH$$/3178.dat';

--
-- Data for Name: customer_order_item; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.customer_order_item (customer_order_item_id, order_id, product_id, quantity, list_price, product_discount, store_id) FROM stdin;
\.
COPY public.customer_order_item (customer_order_item_id, order_id, product_id, quantity, list_price, product_discount, store_id) FROM '$$PATH$$/3175.dat';

--
-- Data for Name: customer_review; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.customer_review (review_id, customer_id, customer_comment, customer_rating, product_id, reply_review_id) FROM stdin;
\.
COPY public.customer_review (review_id, customer_id, customer_comment, customer_rating, product_id, reply_review_id) FROM '$$PATH$$/3177.dat';

--
-- Data for Name: postal_service; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.postal_service (service_id, postalservicename, price, avg_delivery_day) FROM stdin;
\.
COPY public.postal_service (service_id, postalservicename, price, avg_delivery_day) FROM '$$PATH$$/3171.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.product (product_id, product_name, brand_id, category_id, sub_type, product_color, product_image, product_width, product_height, product_weight, box_pieces, model_year, list_price, discount, description, listed) FROM stdin;
\.
COPY public.product (product_id, product_name, brand_id, category_id, sub_type, product_color, product_image, product_width, product_height, product_weight, box_pieces, model_year, list_price, discount, description, listed) FROM '$$PATH$$/3165.dat';

--
-- Data for Name: product_sales_statistic; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.product_sales_statistic (product_id, number_sold, product_rating, number_viewed, date_added) FROM stdin;
\.
COPY public.product_sales_statistic (product_id, number_sold, product_rating, number_viewed, date_added) FROM '$$PATH$$/3166.dat';

--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.stock (stock_id, store_id, product_id, quantity) FROM stdin;
\.
COPY public.stock (stock_id, store_id, product_id, quantity) FROM '$$PATH$$/3170.dat';

--
-- Data for Name: store; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.store (store_id, store_name, phone_number, email) FROM stdin;
\.
COPY public.store (store_id, store_name, phone_number, email) FROM '$$PATH$$/3159.dat';

--
-- Data for Name: store_address; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.store_address (store_id, country_tag, province, district, neighborhood, zip_code, address_text_primary, address_text_secondary) FROM stdin;
\.
COPY public.store_address (store_id, country_tag, province, district, neighborhood, zip_code, address_text_primary, address_text_secondary) FROM '$$PATH$$/3167.dat';

--
-- Data for Name: store_sales_statistic; Type: TABLE DATA; Schema: public; Owner: service
--

COPY public.store_sales_statistic (store_id, item_sold) FROM stdin;
\.
COPY public.store_sales_statistic (store_id, item_sold) FROM '$$PATH$$/3168.dat';

--
-- Name: account_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.account_seq', 14, true);


--
-- Name: brand_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.brand_seq', 1, false);


--
-- Name: category_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.category_seq', 1, false);


--
-- Name: customer_basket_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.customer_basket_seq', 1, false);


--
-- Name: customer_order_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.customer_order_address_id_seq', 16, true);


--
-- Name: customer_order_item_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.customer_order_item_seq', 40, true);


--
-- Name: customer_order_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.customer_order_seq', 23, true);


--
-- Name: customer_review_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.customer_review_review_id_seq', 331, true);


--
-- Name: customer_review_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.customer_review_seq', 2, true);


--
-- Name: customer_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.customer_seq', 13, true);


--
-- Name: product_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.product_seq', 1, false);


--
-- Name: stock_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.stock_seq', 1, false);


--
-- Name: store_seq; Type: SEQUENCE SET; Schema: public; Owner: service
--

SELECT pg_catalog.setval('public.store_seq', 1, false);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (account_id);


--
-- Name: basket_item basket_item_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.basket_item
    ADD CONSTRAINT basket_item_pkey PRIMARY KEY (basket_item_id);


--
-- Name: brand brand_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.brand
    ADD CONSTRAINT brand_pkey PRIMARY KEY (brand_id);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (category_id);


--
-- Name: customer customer_account_id_key; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_account_id_key UNIQUE (account_id);


--
-- Name: customer_basket customer_basket_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_basket
    ADD CONSTRAINT customer_basket_customer_id_key UNIQUE (customer_id);


--
-- Name: customer_basket customer_basket_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_basket
    ADD CONSTRAINT customer_basket_pkey PRIMARY KEY (basket_id);


--
-- Name: customer_order_address customer_order_address_order_id_key; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order_address
    ADD CONSTRAINT customer_order_address_order_id_key UNIQUE (order_id);


--
-- Name: customer_order_address customer_order_address_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order_address
    ADD CONSTRAINT customer_order_address_pkey PRIMARY KEY (id);


--
-- Name: customer_order_item customer_order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order_item
    ADD CONSTRAINT customer_order_item_pkey PRIMARY KEY (customer_order_item_id);


--
-- Name: customer_order customer_order_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_pkey PRIMARY KEY (order_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: customer_review customer_review_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_review
    ADD CONSTRAINT customer_review_pkey PRIMARY KEY (review_id);


--
-- Name: postal_service postal_service_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.postal_service
    ADD CONSTRAINT postal_service_pkey PRIMARY KEY (service_id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: product_sales_statistic product_sales_statistic_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.product_sales_statistic
    ADD CONSTRAINT product_sales_statistic_pkey PRIMARY KEY (product_id);


--
-- Name: stock stock_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (stock_id);


--
-- Name: store_address store_address_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.store_address
    ADD CONSTRAINT store_address_pkey PRIMARY KEY (store_id);


--
-- Name: store store_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.store
    ADD CONSTRAINT store_pkey PRIMARY KEY (store_id);


--
-- Name: store_sales_statistic store_sales_statistic_pkey; Type: CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.store_sales_statistic
    ADD CONSTRAINT store_sales_statistic_pkey PRIMARY KEY (store_id);


--
-- Name: idx_customer_order_customer_id; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX idx_customer_order_customer_id ON public.customer_order USING btree (customer_id);


--
-- Name: idx_customer_review_customer_id; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX idx_customer_review_customer_id ON public.customer_review USING btree (customer_id);


--
-- Name: idx_customer_review_product_id; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX idx_customer_review_product_id ON public.customer_review USING btree (customer_id);


--
-- Name: idx_product_list_price; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX idx_product_list_price ON public.product USING btree (list_price);


--
-- Name: idx_product_name; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX idx_product_name ON public.product USING btree (product_name);


--
-- Name: idx_stock_product_id; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX idx_stock_product_id ON public.stock USING btree (product_id);


--
-- Name: idx_store_address_zip_code; Type: INDEX; Schema: public; Owner: service
--

CREATE INDEX idx_store_address_zip_code ON public.store_address USING btree (zip_code);


--
-- Name: basket_item basket_item_basket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.basket_item
    ADD CONSTRAINT basket_item_basket_id_fkey FOREIGN KEY (basket_id) REFERENCES public.customer_basket(basket_id) ON DELETE CASCADE;


--
-- Name: basket_item basket_item_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.basket_item
    ADD CONSTRAINT basket_item_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id) ON DELETE CASCADE;


--
-- Name: customer customer_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.account(account_id) ON DELETE CASCADE;


--
-- Name: customer_basket customer_basket_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_basket
    ADD CONSTRAINT customer_basket_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id) ON DELETE CASCADE;


--
-- Name: customer_order_address customer_order_address_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order_address
    ADD CONSTRAINT customer_order_address_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.customer_order(order_id) ON DELETE CASCADE;


--
-- Name: customer_order customer_order_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: customer_order_item customer_order_item_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order_item
    ADD CONSTRAINT customer_order_item_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.customer_order(order_id) ON DELETE CASCADE;


--
-- Name: customer_order_item customer_order_item_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order_item
    ADD CONSTRAINT customer_order_item_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: customer_order_item customer_order_item_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order_item
    ADD CONSTRAINT customer_order_item_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store(store_id) ON DELETE SET NULL;


--
-- Name: customer_order customer_order_postal_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_postal_service_id_fkey FOREIGN KEY (postal_service_id) REFERENCES public.postal_service(service_id) ON DELETE SET NULL;


--
-- Name: customer_review customer_review_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_review
    ADD CONSTRAINT customer_review_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id) ON DELETE CASCADE;


--
-- Name: customer_review customer_review_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.customer_review
    ADD CONSTRAINT customer_review_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id) ON DELETE CASCADE;


--
-- Name: product product_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brand(brand_id);


--
-- Name: product product_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.category(category_id);


--
-- Name: product_sales_statistic product_sales_statistic_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.product_sales_statistic
    ADD CONSTRAINT product_sales_statistic_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id) ON DELETE CASCADE;


--
-- Name: stock stock_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id) ON DELETE CASCADE;


--
-- Name: stock stock_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store(store_id) ON DELETE CASCADE;


--
-- Name: store_address store_address_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.store_address
    ADD CONSTRAINT store_address_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store(store_id) ON DELETE CASCADE;


--
-- Name: store_sales_statistic store_sales_statistic_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: service
--

ALTER TABLE ONLY public.store_sales_statistic
    ADD CONSTRAINT store_sales_statistic_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store(store_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

